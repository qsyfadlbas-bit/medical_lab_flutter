import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:medical_lab_flutter/models/user_model.dart';
import 'package:medical_lab_flutter/services/api_service.dart';

class AuthProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();

  User? _currentUser;
  String? _token;
  bool _isLoading = false;
  String? _errorMessage;

  User? get currentUser => _currentUser;
  String? get token => _token;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  bool get isAuthenticated => _token != null;

  // ✅ دالة التحقق من تسجيل الدخول التلقائي عند بدء التطبيق
  Future<String?> tryAutoLogin() async {
    final prefs = await SharedPreferences.getInstance();
    if (!prefs.containsKey('token')) {
      return null;
    }

    _token = prefs.getString('token');
    final role = prefs.getString('userRole');

    // ✅ جلب بيانات المستخدم المحدثة (بما فيها الـ address) من السيرفر
    await fetchUserProfile();

    notifyListeners();
    return role; // إرجاع الرول لتوجيه المستخدم
  }

  // ✅ دالة جلب بيانات الملف الشخصي من السيرفر
  Future<void> fetchUserProfile() async {
    if (_token == null) return;

    try {
      final response = await _apiService.get('/auth/profile');

      // التأكد من نجاح الطلب
      if (response.statusCode == 200 || response.statusCode == 201) {
        final body = json.decode(response.body);

        // التحقق من بنية الرد القادم من الباك إند
        if (body['success'] == true && body['data'] != null) {
          _currentUser = User.fromJson(body['data']);

          // تحديث البيانات في الذاكرة المحلية (اختياري لكن مفضل)
          final prefs = await SharedPreferences.getInstance();
          await prefs.setString('userName', _currentUser?.name ?? 'مستخدم');
          await prefs.setString('userRole', _currentUser?.role ?? 'USER');

          notifyListeners();
          print("✅ Profile Fetched Successfully: ${_currentUser?.name}");
        }
      } else {
        print("❌ Failed to fetch profile: Status ${response.statusCode}");
      }
    } catch (e) {
      print('❌ fetchUserProfile error: $e');
    }
  }

  // تسجيل الدخول
  Future<bool> login({
    required String username,
    required String password,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      print("🚀 Login Attempt: $username");

      final response = await _apiService.post('/auth/login', {
        'username': username,
        'password': password,
      });

      print("📡 Response Status: ${response.statusCode}");

      final Map<String, dynamic> body = json.decode(response.body);

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (body['success'] == true && body['data'] != null) {
          final data = body['data'];

          _token = data['token'];
          _currentUser = User.fromJson(data['user']);

          // ✅ حفظ البيانات باستخدام SharedPreferences
          if (_token != null) {
            final prefs = await SharedPreferences.getInstance();
            await prefs.setString('token', _token!);
            await prefs.setString('userRole', _currentUser?.role ?? 'USER');
            await prefs.setString('userName', _currentUser?.name ?? 'مستخدم');
          }

          print("✅ Login Success");
          return true;
        }
      }

      _errorMessage = body['error'] ?? body['message'] ?? 'فشل تسجيل الدخول';
      print("❌ Login Failed: $_errorMessage");
      return false;
    } catch (e) {
      print("❌ Login Exception: $e");
      _errorMessage = 'خطأ في الاتصال بالسيرفر';
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // تسجيل حساب جديد
  Future<bool> register({
    required String name,
    required String username,
    required String email,
    required String password,
    required String address,
    String? phone,
    String? adminCode,
  }) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      print("🚀 Register Attempt: $email");

      final response = await _apiService.post('/auth/register', {
        'name': name,
        'username': username,
        'email': email,
        'password': password,
        'phone': phone,
        'address': address,
        'adminCode': adminCode,
      });

      print("📡 Response Status: ${response.statusCode}");

      final Map<String, dynamic> body = json.decode(response.body);

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (body['success'] == true && body['data'] != null) {
          final data = body['data'];

          _token = data['token'];
          _currentUser = User.fromJson(data['user']);

          // ✅ حفظ البيانات باستخدام SharedPreferences
          if (_token != null) {
            final prefs = await SharedPreferences.getInstance();
            await prefs.setString('token', _token!);
            await prefs.setString('userRole', _currentUser?.role ?? 'USER');
            await prefs.setString('userName', _currentUser?.name ?? 'مستخدم');
          }

          print("✅ Register Success");
          return true;
        }
      }

      _errorMessage = body['error'] ?? body['message'] ?? 'فشل إنشاء الحساب';
      print("❌ Register Failed: $_errorMessage");
      return false;
    } catch (e) {
      print("❌ Register Exception: $e");
      _errorMessage = 'خطأ في الاتصال بالسيرفر';
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // تسجيل الخروج
  Future<void> logout() async {
    _token = null;
    _currentUser = null;

    // ✅ مسح البيانات من SharedPreferences
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    notifyListeners();
  }
}
