import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:medical_lab_flutter/models/user_model.dart';
import 'package:medical_lab_flutter/services/api_service.dart';

class UserProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();

  List<User> _users = [];
  User? _currentUser;
  bool _isLoading = false;
  String? _errorMessage;

  // Getters
  List<User> get users => _users;
  User? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  void setCurrentUser(User? user) {
    _currentUser = user;
    notifyListeners();
  }

  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }

  // ✅ دالة لجلب جميع المستخدمين (تستخدم في لوحة تحكم الأدمن أو عرض المستخدمين)
  Future<void> fetchUsers() async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final response = await _apiService.get('/users');

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true && data['data'] != null) {
          final List<dynamic> list = data['data'];
          _users = list.map((e) => User.fromJson(e)).toList();
        }
      } else {
        _errorMessage = 'فشل تحميل القائمة (${response.statusCode})';
      }
    } catch (e) {
      _errorMessage = 'خطأ في الاتصال: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // ✅ دالة تحديث الملف الشخصي بالمسار الصحيح المطابق للباك إند
  // تم الاحتفاظ بالاسم updateUserProfile لدعم الشاشات القديمة إذا كانت تستخدمه
  Future<bool> updateUserProfile(Map<String, dynamic> updateData) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      // ✅ المسار الصحيح كما حددته أنت (/auth/update-profile)
      final response =
          await _apiService.put('/auth/update-profile', updateData);

      if (response.statusCode == 200 || response.statusCode == 201) {
        final responseData = json.decode(response.body);

        // تحديث المستخدم الحالي محلياً إذا رجع السيرفر البيانات الجديدة
        if (responseData['success'] == true && responseData['data'] != null) {
          _currentUser = User.fromJson(responseData['data']);
        }
        return true;
      } else {
        final body = json.decode(response.body);
        _errorMessage =
            body['error'] ?? body['message'] ?? 'فشل تحديث البيانات';
        return false;
      }
    } catch (e) {
      print("Update Profile Error: $e");
      _errorMessage = 'خطأ في الاتصال بالسيرفر';
      return false;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
